/*	INODE AND SUPERBLOCK STRUCTURES
 *	copyright (c) 1980 by Whitesmiths, Ltd.
 */

/*	scalar types
 */
#define BLOCK	UCOUNT
#define INUM	UCOUNT
#define UID		UTINY

/*	the filesystem superblock
 */
typedef struct {
	BLOCK s_isize;
	BLOCK s_fsize;
	UCOUNT s_nfree;
	BLOCK s_free[100];
	UCOUNT s_ninode;
	INUM s_inode[100];
	TEXT s_pad[4];
	LONG s_time;
	} FILSYS;

/*	inode usage bits
 */
#define IALLOC	0100000
#define IFMT	060000
#define ILARG	010000
#define ISUID	004000
#define ISGID	002000

/*	the filesystem inode
 */
typedef struct {
	BITS n_mode;
	TEXT n_link;
	UID n_uid;
	UID n_gid;
	UTINY n_size0;
	UCOUNT n_size1;
	BLOCK n_addr[8];
	LONG n_actime;
	LONG n_uptime;
	} FINODE;
